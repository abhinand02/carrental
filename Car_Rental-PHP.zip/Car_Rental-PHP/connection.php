<?php

// function Connect()
// {
// 	$dbhost = "localhost";
// 	$dbuser = "root";
// 	$dbpass = "";
// 	$dbname = "carrentalp";

// 	//Create Connection
// 	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname) or die($conn->connect_error);

// 	return $conn;
// }
$conn=mysqli_connect("localhost", "root", "","carrentalp");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}
?>