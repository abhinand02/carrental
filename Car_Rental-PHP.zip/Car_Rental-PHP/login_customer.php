<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message

// if (isset($_POST['submit'])) {
// if (empty($_POST['customer_username']) || empty($_POST['customer_password'])) {
// $error = "Username or Password is invalid";
// Define $username and $password
// $customer_username=$_POST['customer_username'];
// $customer_password=$_POST['customer_password'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
// require 'connection.php';
// $conn = Connect();

// SQL query to fetch information of registerd users and finds user match.
// $query = "SELECT customer_username, customer_password FROM customers WHERE customer_username=? AND customer_password=? LIMIT 1";

// To protect MySQL injection for Security purpose
// $smt=mysqli_query($query,$conn);
// $stmt = $conn->prepare($query);
// $stmt -> bind_param("ss", $customer_username, $customer_password);
// $stmt -> execute();
// $stmt -> bind_result($customer_username, $customer_password);
// $stmt -> store_result();

// if ($stmt->fetch())  //fetching the contents of the row
// {
	// $_SESSION['login_customer']=$customer_username; // Initializing Session
	// header("location: index.php"); // Redirecting To Other Page
// } else {
// $error = "Username or Password is invalid";
// }
// mysqli_close($conn); // Closing Connection
// }
 include("connection.php");
if (isset($_POST['submit']))
{
	$customer_username=$_POST['customer_username'];
    $customer_password=$_POST['customer_password'];

	$query = "SELECT customer_username, customer_password FROM customers WHERE
	 customer_username=? AND customer_password=? LIMIT 1";
    
	// $res=mysqli_query($conn,$query);
    $res = $conn->prepare($query);
	$res -> bind_param("ss", $customer_username, $customer_password);
	$res -> execute();
	if ($res->fetch()) 
	{
		$_SESSION['login_customer']=$customer_username;
        header("location: index.php");
		
	} else {
		$error = "Username or Password is invalid";
		// $_SESSION['message']="Incorrect Username or Password."
		// echo "<h3>Invalid username or password</h3>";
		}
		mysqli_close($conn);
	
}


?>